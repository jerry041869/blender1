import bpy, math, random, os, sys
from mathutils import Vector
OUT='/workspace/output/slimesweep_video'
kind=os.environ.get('SWEEP_SCENE','keyboard')
random.seed(42)
bpy.ops.wm.open_mainfile(filepath='/workspace/output/slimesweep/SlimeSweep_V3.blend')
sc=bpy.context.scene
for o in list(sc.objects):
 if o.type in {'LIGHT','CAMERA'} or o.name=='Studio floor': bpy.data.objects.remove(o,do_unlink=True)
root=bpy.data.objects.new('Animated SlimeSweep assembly',None);sc.collection.objects.link(root)
for o in list(sc.objects):
 if o!=root:o.parent=root
# Stable, economical materials for real-time animation rendering.
for m in bpy.data.materials:
 if m.use_nodes:
  p=m.node_tree.nodes.get('Principled BSDF')
  if p:
   p.inputs['Transmission Weight'].default_value=0
   if 'reservoir' in m.name:p.inputs['Base Color'].default_value=(.38,.57,.32,1);p.inputs['Metallic'].default_value=.25;p.inputs['Roughness'].default_value=.2
   if 'cleaning gel' in m.name:p.inputs['Base Color'].default_value=(.57,.72,.12,1);p.inputs['Roughness'].default_value=.22;p.inputs['Subsurface Weight'].default_value=.12
def mat(n,c,rough=.5):
 m=bpy.data.materials.new(n);m.diffuse_color=(*c,1);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*c,1);p.inputs['Roughness'].default_value=rough;return m
def box(n,loc,dim,m,b=.08):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.name=n;o.dimensions=dim;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(m)
 if b:mod=o.modifiers.new('Rounded edges','BEVEL');mod.width=b;mod.segments=3;o.modifiers.new('Normals','WEIGHTED_NORMAL')
 return o
def uv(n,loc,dim,m):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=12,ring_count=8,radius=1,location=loc);o=bpy.context.object;o.name=n;o.scale=dim;o.data.materials.append(m)
 for p in o.data.polygons:p.use_smooth=True
 return o
desk=mat('Desk | warm neutral',(.17,.19,.18));black=mat('Keyboard aluminium',(.045,.055,.06),.3);cap=mat('Keycaps charcoal',(.11,.13,.14),.35);accent=mat('Sage accent keys',(.25,.38,.32));label=mat('Key legends',(.7,.75,.7));dustmat=mat('Warm visible dust',(.38,.26,.13));hairmat=mat('Lint strands',(.29,.23,.18))
box('Studio tabletop',(-4,0,-.36),(100,100,.5),desk)
if kind=='keyboard':
 box('Mechanical keyboard chassis',(-14,0,.05),(15,8.4,.55),black,.22)
 legends=['QWERTYUI','ASDFGHJK','ZXCVBNM,','12345678']
 for row,y in enumerate([-3.15,-1.08,1.08,3.15]):
  for col in range(8):
   x=-20.5+col*1.86
   box('Keycap %s%d'%(row,col),(x,y,.78),(1.62,1.64,.82),accent if col==0 else cap,.13)
   cu=bpy.data.curves.new('Legend','FONT');cu.body=legends[row][col];cu.size=.36;cu.align_x='CENTER';ob=bpy.data.objects.new('Key legend',cu);sc.collection.objects.link(ob);ob.location=(x,y-.12,1.199);cu.materials.append(label)
 zoff=.50
else:
 wood=mat('Furniture | walnut',(.20,.11,.055),.38)
 # Subtle procedural wood grain.
 nt=wood.node_tree;p=nt.nodes.get('Principled BSDF');tex=nt.nodes.new('ShaderNodeTexNoise');tex.inputs['Scale'].default_value=3;tex.inputs['Detail'].default_value=2
 mapping=nt.nodes.new('ShaderNodeVectorMath');mapping.operation='MULTIPLY';mapping.inputs[1].default_value=(.12,4,12);coord=nt.nodes.new('ShaderNodeTexCoord');nt.links.new(coord.outputs['Generated'],mapping.inputs[0]);nt.links.new(mapping.outputs[0],tex.inputs['Vector'])
 ramp=nt.nodes.new('ShaderNodeValToRGB');ramp.color_ramp.elements[0].color=(.055,.027,.012,1);ramp.color_ramp.elements[1].color=(.28,.16,.08,1);nt.links.new(tex.outputs['Fac'],ramp.inputs[0]);nt.links.new(ramp.outputs[0],p.inputs['Base Color'])
 box('Cabinet base above difficult gap',(-13.3,1,3.15),(13.2,9,3.50),wood,.08)
 box('Recessed cabinet foot',(-15,3,.6),(2,1.1,1.6),black)
 zoff=.25
# Approach, compress to enter the gap, collect, then lift and withdraw.
motion=[(1,(5,0,zoff+1.8)),(24,(3.1,0,zoff+.45)),(48,(0,0,zoff)),(68,(0,0,zoff)),(88,(2.1,0,zoff+.7)),(112,(5,0,zoff+2.2))]
for frame,loc in motion:root.location=loc;root.keyframe_insert(data_path='location',frame=frame)
gel=bpy.data.objects.get('20 | Irregular extruded cleaning gel')
for f,s in [(1,(1,.68,1)),(24,(1,.6,1)),(48,(1,.34,.68)),(68,(1,.34,.68)),(88,(1.07,.52,.85)),(112,(1,.68,1))]:gel.scale=s;gel.keyframe_insert(data_path='scale',frame=f)
for o in root.children:
 if o.name.startswith('22 |'):o.hide_render=True
slider=bpy.data.objects.get('15 | Sage push slider');sx=slider.location.x
for f,x in [(1,sx+.7),(24,sx+.7),(48,sx),(68,sx),(88,sx+.7),(112,sx+.7)]:slider.location.x=x;slider.keyframe_insert(data_path='location',frame=f)
# Each dust particle remains stationary until the gel contacts it, then follows
# the gel away from the surface; no hidden clean replacement surface is used.
for i in range(68):
 pos=Vector((random.uniform(-9.6,-7.3),random.uniform(-.26,.26),.39 if kind=='keyboard' else -.04))
 o=uv('Picked-up dust %03d'%i,pos,(random.uniform(.06,.11),random.uniform(.04,.08),random.uniform(.03,.08)),dustmat)
 for frame in [1,48,64]:o.location=pos;o.keyframe_insert(data_path='location',frame=frame)
 for frame,loc in motion:
  if frame>=68:
   o.location=pos+Vector(loc)-Vector((0,0,zoff))+Vector((0,-.45,.17));o.keyframe_insert(data_path='location',frame=frame)
for i in range(9):
 pos=Vector((random.uniform(-9.4,-7.5),random.uniform(-.22,.22),.40 if kind=='keyboard' else -.03))
 cu=bpy.data.curves.new('Dust lint','CURVE');cu.dimensions='3D';cu.bevel_depth=.014;cu.bevel_resolution=2;s=cu.splines.new('BEZIER');s.bezier_points.add(3)
 for j,p in enumerate(s.bezier_points):p.co=(j*.13,math.sin(j*1.9+i)*.06,0);p.handle_left_type='AUTO';p.handle_right_type='AUTO'
 o=bpy.data.objects.new('Picked-up lint %02d'%i,cu);sc.collection.objects.link(o);cu.materials.append(hairmat)
 for frame in [1,48,64]:o.location=pos;o.keyframe_insert(data_path='location',frame=frame)
 for frame,loc in motion:
  if frame>=68:o.location=pos+Vector(loc)-Vector((0,0,zoff))+Vector((0,-.45,.17));o.keyframe_insert(data_path='location',frame=frame)
def area(loc,power,size,col):
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.data.energy=power;o.data.shape='DISK';o.data.size=size;o.data.color=col;o.rotation_euler=(Vector((-5,0,0))-o.location).to_track_quat('-Z','Y').to_euler()
area((-4,-8,15),2300,12,(1,.91,.78));area((0,7,12),2100,10,(.77,.88,1));area((-15,-5,6),1200,8,(1,.97,.83))
if kind!='keyboard':
 area((-10,-5,1.2),180,4,(1,.95,.82))
bpy.ops.object.camera_add();cam=bpy.context.object;sc.camera=cam;cam.data.type='ORTHO'
for f,loc,target,scale in [(1,(-8,-29,34),(-4.5,0,.7),35),(48,(-9,-18,38),(-7.5,0,.6),23),(68,(-9,-18,38),(-7.5,0,.6),23),(112,(-8,-29,34),(-4.5,0,1.0),35)]:
 if kind!='keyboard':loc=(loc[0],-32,8 if f in [48,68] else 12)
 cam.location=loc;cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler();cam.keyframe_insert(data_path='location',frame=f);cam.keyframe_insert(data_path='rotation_euler',frame=f);cam.data.ortho_scale=scale;cam.data.keyframe_insert(data_path='ortho_scale',frame=f)
sc.render.engine='CYCLES';sc.cycles.samples=12;sc.cycles.use_denoising=False;sc.cycles.max_bounces=3
sc.render.resolution_x=800;sc.render.resolution_y=450;sc.render.resolution_percentage=100;sc.render.fps=16;sc.frame_start=1;sc.frame_end=112;sc.frame_step=2
sc.world.color=(.35,.35,.35);sc.render.image_settings.file_format='PNG';sc.render.filepath=OUT+'/'+kind+'/frame_';os.makedirs(OUT+'/'+kind,exist_ok=True)
sc['Animation scope']='Concept demonstration: keyframed gel deformation and dust pickup, not validated adhesion physics.'
sc.frame_set(1);bpy.ops.wm.save_as_mainfile(filepath=OUT+'/SlimeSweep_'+kind+'_animation.blend')
if '--preview' in sys.argv:
 sc.frame_set(56);sc.cycles.samples=16;sc.render.filepath=OUT+'/'+kind+'_preview.png';bpy.ops.render.render(write_still=True)
else:bpy.ops.render.render(animation=True)
