import pathlib, subprocess, json, zipfile
P=pathlib.Path('/workspace/output/slimesweep_video')
font='/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc'
def run(args):subprocess.run(args,check=True)
for kind,title in [('keyboard','01  機械鍵盤｜鍵帽間隙除塵'),('crevice','02  家具底部｜狹窄縫隙除塵')]:
 frames=sorted((P/kind).glob('frame_*.png'))
 assert len(frames)==56,(kind,len(frames))
 # Numbered sequential links retain the original Blender timeline frame names.
 seq=P/(kind+'_sequence');seq.mkdir(exist_ok=True)
 for i,f in enumerate(frames):
  dest=seq/('%04d.png'%i)
  if not dest.exists():dest.symlink_to(f)
 def caption(text,name,y,size,start=None,end=None):
  f=P/(kind+'_'+name+'.txt');f.write_text(text)
  filt=f'drawtext=fontfile={font}:textfile={f}:fontcolor=white:fontsize={size}:x=28:y={y}:box=1:boxcolor=black@0.55:boxborderw=10'
  if start is not None:filt+=f":enable='between(t,{start},{end})'"
  return filt
 filters=['hqdn3d=6:5:7:5','nlmeans=s=6:p=5:r=7','tpad=stop_mode=clone:stop_duration=0.4','minterpolate=fps=24:mi_mode=mci:mc_mode=aobmc:me_mode=bidir:vsbmc=1',caption(title,'title',25,24),caption('SlimeSweep V3  ·  Blender 概念使用動畫','footer',420,12)]
 for i,(text,a,b) in enumerate([('靠近清潔區域',0,1.6),('推進凝膠，貼合縫隙',1.6,3.0),('凝膠接觸並黏附灰塵',3.0,4.4),('拉回凝膠，帶出灰塵與棉絮',4.4,7)]):filters.append(caption(text,'step'+str(i),382,20,a,b))
 run(['ffmpeg','-hide_banner','-loglevel','warning','-y','-framerate','8','-i',str(seq/'%04d.png'),'-vf',','.join(filters),'-t','7','-c:v','libx264','-preset','medium','-crf','19','-pix_fmt','yuv420p','-movflags','+faststart',str(P/('SlimeSweep_'+kind+'.mp4'))])
concat=P/'concat.txt';concat.write_text("file 'SlimeSweep_keyboard.mp4'\nfile 'SlimeSweep_crevice.mp4'\n")
run(['ffmpeg','-hide_banner','-loglevel','warning','-y','-f','concat','-safe','0','-i',str(concat),'-c','copy','-movflags','+faststart',str(P/'SlimeSweep_usage_demo.mp4')])
with zipfile.ZipFile(P/'SlimeSweep_animation_sources.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in ['SlimeSweep_keyboard_animation.blend','SlimeSweep_crevice_animation.blend','animate.py','encode.py','README.md']:z.write(P/name,name)
for name in ['SlimeSweep_keyboard.mp4','SlimeSweep_crevice.mp4','SlimeSweep_usage_demo.mp4']:
 run(['ffprobe','-v','error','-show_entries','stream=codec_name,width,height,avg_frame_rate,nb_frames:format=duration','-of','json',str(P/name)])
