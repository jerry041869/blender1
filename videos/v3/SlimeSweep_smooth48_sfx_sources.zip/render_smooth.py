import bpy,pathlib,os
P=pathlib.Path('/workspace/output/slimesweep_v3');OLD=P.parent/'slimesweep_v2'
for kind in ['keyboard','crevice','seat']:
 bpy.ops.wm.open_mainfile(filepath=str(OLD/('SlimeSweep_'+kind+'_v2.blend')))
 s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.samples=4;s.cycles.use_adaptive_sampling=False;s.cycles.use_denoising=False;s.cycles.max_bounces=3;s.cycles.diffuse_bounces=1;s.cycles.glossy_bounces=2;s.cycles.transmission_bounces=2;s.render.use_persistent_data=True
 p=bpy.data.materials['Translucent chartreuse slime'].node_tree.nodes.get('Principled BSDF');p.inputs['Subsurface Weight'].default_value=0;p.inputs['Transmission Weight'].default_value=.12
 s.view_layers[0].cycles.denoising_store_passes=True;s.render.image_settings.file_format='OPEN_EXR_MULTILAYER';s.render.image_settings.color_depth='16';s.render.image_settings.exr_codec='ZIP'
 s.frame_start=1;s.frame_end=72;s.frame_step=1;s.render.fps=9;s.frame_set(1);s.render.filepath=str(P/kind/'guided'/'frame_')
 bpy.ops.wm.save_as_mainfile(filepath=str(P/('SlimeSweep_'+kind+'_smooth.blend')))
 for f in range(2,73,2):
  path=P/kind/'guided'/('frame_%04d.exr'%f)
  if path.exists():continue
  tmp=path.with_name('partial_'+path.name);s.frame_set(f);s.render.filepath=str(tmp);bpy.ops.render.render(write_still=True);os.replace(tmp,path)
  print('ADDED_INTERMEDIATE_FRAME',kind,f,flush=True)
