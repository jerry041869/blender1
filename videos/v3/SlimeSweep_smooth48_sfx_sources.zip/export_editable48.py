import bpy,pathlib,time
P=pathlib.Path('/workspace/output/slimesweep_v3');factor=48/9
for kind in ['keyboard','crevice','seat']:
 source=P/('SlimeSweep_'+kind+'_smooth.blend')
 while not source.exists() or time.time()-source.stat().st_mtime<3:time.sleep(2)
 bpy.ops.wm.open_mainfile(filepath=str(source))
 for action in bpy.data.actions:
  for fc in action.fcurves:
   checks=[(f,fc.evaluate(f)) for f in [1,18,30,45,54,62,68,72]]
   for k in fc.keyframe_points:
    k.co.x=1+(k.co.x-1)*factor;k.handle_left.x=1+(k.handle_left.x-1)*factor;k.handle_right.x=1+(k.handle_right.x-1)*factor
   fc.update()
   assert all(abs(fc.evaluate(1+(f-1)*factor)-v)<.001 for f,v in checks),fc.data_path
 s=bpy.context.scene;s.render.fps=48;s.frame_start=1;s.frame_end=384;s.frame_step=1;s.frame_set(1)
 s['Audio delivery']=kind+'_sfx.wav, stereo 48kHz; mixed into delivered MP4'
 bpy.ops.wm.save_as_mainfile(filepath=str(P/('SlimeSweep_'+kind+'_editable48.blend')))
 print('EDITABLE_48FPS_EXPORTED',kind,flush=True)
