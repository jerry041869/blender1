import pathlib,subprocess,time,json
P=pathlib.Path('/workspace/output/slimesweep_v3');font='/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc'
def run(a):subprocess.run(a,check=True)
for kind,title in [('keyboard','01  機械鍵盤縫隙'),('crevice','02  家具底部狹縫'),('seat','03  座椅之間的縫隙')]:
 existing=P/('SlimeSweep_'+kind+'_smooth48_sfx.mp4')
 if existing.exists():
  try:
   probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(existing)],stderr=subprocess.DEVNULL))
   video=next(x for x in probe['streams'] if x['codec_type']=='video');audio=next(x for x in probe['streams'] if x['codec_type']=='audio')
   valid=(video.get('nb_frames')=='384' and video.get('avg_frame_rate')=='48/1' and video.get('width')==1920 and audio.get('channels')==2 and abs(float(probe['format']['duration'])-8)<.02)
  except (subprocess.CalledProcessError,KeyError,StopIteration,ValueError):valid=False
  if valid:print('REUSING_COMPLETE_CLIP',kind,flush=True);continue
 while True:
  frames=sorted((P/kind/'final').glob('frame_*.png'))
  if len(frames)==72 and all(time.time()-f.stat().st_mtime>3 for f in frames):break
  time.sleep(2)
 assert [int(f.stem[6:]) for f in frames]==list(range(1,73))
 def txt(s,n,y,size,a=None,b=None):
  f=P/(kind+'_'+n+'.txt');f.write_text(s);v=f'drawtext=fontfile={font}:textfile={f}:fontcolor=white:fontsize={size}:x=48:y={y}:box=1:boxcolor=black@0.5:boxborderw=16'
  if a is not None:v+=f":enable='between(t,{a},{b})'"
  return v
 filters=['tpad=stop_mode=clone:stop_duration=0.5','minterpolate=fps=48:mi_mode=mci:mc_mode=aobmc:me_mode=bidir:vsbmc=1',txt(title,'title',42,44),txt('SlimeSweep V3  |  推出擴散 → 吸附髒污 → 回拉收膠','footer',1010,24)]
 for i,(s,a,b) in enumerate([('向前推動滑塊，凝膠從出口延伸',0,1.87),('不規則分枝擴散，貼合縫隙',1.87,4.27),('灰塵緊密黏附在凝膠表面',4.27,5.33),('向後拉動滑塊，凝膠收攏並回收到出口內',5.33,8)]):filters.append(txt(s,'step'+str(i),930,38,a,b))
 run(['ffmpeg','-hide_banner','-loglevel','warning','-y','-filter_threads','1','-framerate','9','-start_number','1','-i',str(P/kind/'final'/'frame_%04d.png'),'-i',str(P/(kind+'_sfx.wav')),'-vf',','.join(filters),'-t','8','-c:v','libx264','-threads','2','-preset','medium','-crf','18','-pix_fmt','yuv420p','-c:a','aac','-b:a','192k','-ar','48000','-movflags','+faststart',str(P/('SlimeSweep_'+kind+'_smooth48_sfx.mp4'))])
 print('ENCODED',kind,flush=True)
files=[P/('SlimeSweep_'+k+'_smooth48_sfx.mp4') for k in ['keyboard','crevice','seat']]
args=['ffmpeg','-hide_banner','-loglevel','warning','-y','-filter_complex_threads','1']
for f in files:args+=['-i',str(f)]
graph='[0:v]setpts=PTS-STARTPTS,fps=48,settb=1/48[v0];[1:v]setpts=PTS-STARTPTS,fps=48,settb=1/48[v1];[2:v]setpts=PTS-STARTPTS,fps=48,settb=1/48[v2];[v0][v1]xfade=transition=fade:duration=0.5:offset=7.5,fps=48,settb=1/48[v01];[v01][v2]xfade=transition=fade:duration=0.5:offset=15,fps=48[v];[0:a][1:a]acrossfade=d=0.5:c1=tri:c2=tri[a01];[a01][2:a]acrossfade=d=0.5:c1=tri:c2=tri[a]'
args+=['-filter_complex',graph,'-map','[v]','-map','[a]','-t','23','-r','48','-c:v','libx264','-threads','2','-preset','medium','-crf','18','-pix_fmt','yuv420p','-c:a','aac','-b:a','192k','-movflags','+faststart',str(P/'SlimeSweep_smooth48_sfx_full.mp4')];run(args)
print('FULL_ENCODE_COMPLETE',flush=True)
