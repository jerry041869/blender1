import pathlib,wave,numpy as np
P=pathlib.Path('/workspace/output/slimesweep_v3');SR=48000;N=8*SR;t=np.arange(N)/SR
for index,kind in enumerate(['keyboard','crevice','seat']):
 rng=np.random.default_rng(310+index);bus=np.zeros((N,2),dtype=np.float64)
 def band(low,high):
  a=rng.normal(0,1,N);f=np.fft.rfftfreq(N,1/SR);z=np.fft.rfft(a);z*=((f>low)&(f<high));a=np.fft.irfft(z,n=N);return a/(np.std(a)+1e-9)
 def env(a,b,attack=.08,release=.12):
  return np.clip((t-a)/attack,0,1)*np.clip((b-t)/release,0,1)*((t>=a)&(t<=b))
 def mix(a,pan=0):
  bus[:,0]+=a*np.sqrt((1-pan)/2);bus[:,1]+=a*np.sqrt((1+pan)/2)
 # Sliding friction and restrained latch clicks, timed to forward travel.
 mix(.030*band(650,4200)*env(.85,3.85,.15,.18)*( .65+.35*np.sin(t*9)**2),.3)
 for when in [1.84,7.42]:
  u=np.maximum(t-when,0);e=np.exp(-u*100)*((t>=when)&(t<when+.09))
  mix(e*(.11*np.sin(2*np.pi*1700*u)+.035*band(2000,8500)),.25)
 # Modulated low, wet texture for extrusion and branching; no speech/music.
 wet=band(90,850);mod=.6+.4*np.sin(2*np.pi*2.3*t+np.sin(t*8))**2
 mix(.045*wet*mod*env(1.4,4.9,.35,.45),-.15)
 for when in rng.uniform(2.1,5.15,12):
  u=np.maximum(t-when,0);e=np.exp(-u*23)*((t>=when)&(t<when+.22));phase=2*np.pi*(170*u-240*u*u)
  mix(.045*np.sin(phase)*e,rng.uniform(-.3,.1))
 # Fine debris/fabric detail; quieter than the gel and slider.
 mix(.013*band(2200 if kind!='seat' else 800,7500)*env(3.1,5.2,.3,.3)*(.2+.8*np.sin(t*29)**8),-.2)
 # Return stroke: elastic stretch, soft suction and a release at the inlet.
 mix(.043*band(180,1500)*env(5.28,7.73,.2,.22)*(.65+.35*np.sin(t*12)**2),.05)
 u=np.maximum(t-5.3,0);mix(.025*np.sin(2*np.pi*(240*u-36*u*u))*env(5.3,7.5,.25,.35),.05)
 mix(.022*band(900,3800)*env(5.3,7.5,.12,.20),.30)
 bus=np.tanh(bus*1.8);peak=np.max(np.abs(bus));bus*=min(1,.65/max(peak,1e-9))
 pcm=(bus*32767).astype('<i2')
 with wave.open(str(P/(kind+'_sfx.wav')),'wb') as w:w.setnchannels(2);w.setsampwidth(2);w.setframerate(SR);w.writeframes(pcm.tobytes())
 print('SFX',kind,'8s stereo 48kHz peak',float(np.max(np.abs(bus))),flush=True)
