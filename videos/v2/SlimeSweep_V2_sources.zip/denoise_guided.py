import pathlib,time,sys,ctypes,numpy as np,oidn,OpenEXR
from PIL import Image
P=pathlib.Path('/workspace/output/slimesweep_v2');d=oidn.NewDevice()
lib=ctypes.CDLL(str(pathlib.Path(oidn.__file__).parent/'lib.linux.x64/libOpenImageDenoise.so.1.4.3'))
seti=lib.oidnSetDevice1i;seti.argtypes=[ctypes.c_void_p,ctypes.c_char_p,ctypes.c_int];seti(d,b'numThreads',2);oidn.CommitDevice(d)
setb=lib.oidnSetFilter1b;setb.argtypes=[ctypes.c_void_p,ctypes.c_char_p,ctypes.c_bool]
while True:
 count=0
 for kind in ['keyboard','crevice','seat']:
  dest=P/kind/'final';dest.mkdir(parents=True,exist_ok=True)
  for f in sorted((P/kind/'guided').glob('frame_*.exr')):
   p=dest/(f.stem+'.png')
   if p.exists():count+=1;continue
   if time.time()-f.stat().st_mtime<3:continue
   try:
    exr=OpenEXR.File(str(f),separate_channels=True);cs=exr.channels()
    def rgb(name,suffix='RGB'):return np.ascontiguousarray(np.stack([cs['ViewLayer.'+name+'.'+c].pixels for c in suffix],axis=-1),dtype=np.float32)
    color=rgb('Combined');albedo=rgb('Denoising Albedo');normal=rgb('Denoising Normal','XYZ')
   except (OSError,RuntimeError,KeyError,ValueError):continue
   h,w=color.shape[:2];out=np.empty_like(color);flt=oidn.NewFilter(d,'RT');setb(flt,b'hdr',True)
   for n,a in [('color',color),('albedo',albedo),('normal',normal),('output',out)]:oidn.SetSharedFilterImage(flt,n,a,oidn.FORMAT_FLOAT3,w,h)
   oidn.CommitFilter(flt);oidn.ExecuteFilter(flt)
   if oidn.GetDeviceError(d):raise RuntimeError('Guided denoising failed')
   # Display-referred ACES approximation followed by sRGB encoding.
   x=np.maximum(out,0);x=np.clip((x*(2.51*x+.03))/(x*(2.43*x+.59)+.14),0,1);x=np.where(x<=.0031308,12.92*x,1.055*np.power(x,1/2.4)-.055)
   Image.fromarray((x*255).astype('uint8')).save(p);oidn.ReleaseFilter(flt);count+=1;print('GUIDED_CLEAN',kind,f.stem,flush=True)
 if '--preview' in sys.argv or count==108:break
 time.sleep(2)
oidn.ReleaseDevice(d)
