import subprocess,pathlib,zipfile,json,time
P=pathlib.Path('/workspace/output/slimesweep_v2');font='/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc'
def run(a):subprocess.run(a,check=True)
for kind,title in [('keyboard','01  機械鍵盤縫隙'),('crevice','02  家具底部狹縫'),('seat','03  座椅之間的縫隙')]:
 while True:
  frames=sorted((P/kind/'final').glob('frame_*.png'))
  if len(frames)==36 and all(time.time()-f.stat().st_mtime>3 for f in frames):break
  time.sleep(2)
 assert [int(f.stem.split('_')[-1]) for f in frames]==list(range(1,73,2)),kind
 seq=P/kind/'sequence';seq.mkdir(exist_ok=True)
 for i,f in enumerate(frames):
  d=seq/('%04d.png'%i)
  if not d.exists():d.symlink_to(f)
 def text(s,label,y,size,start=None,end=None):
  f=P/(kind+'_'+label+'.txt');f.write_text(s)
  v=f'drawtext=fontfile={font}:textfile={f}:fontcolor=white:fontsize={size}:x=48:y={y}:box=1:boxcolor=black@0.55:boxborderw=16'
  if start is not None:v+=f":enable='between(t,{start},{end})'"
  return v
 filters=['tpad=stop_mode=clone:stop_duration=0.5','minterpolate=fps=24:mi_mode=mci:mc_mode=aobmc:me_mode=bidir:vsbmc=1',text(title,'title',42,44),text('SlimeSweep V3  |  推出擴散 → 吸附髒污 → 回拉收膠','footer',1010,24)]
 for i,(s,a,b) in enumerate([('向前推動滑塊，凝膠從出口延伸',0,1.4),('不規則分枝擴散，貼合縫隙',1.4,3.2),('灰塵緊密黏附在凝膠表面',3.2,4),('向後拉動滑塊，凝膠收攏並回收到出口內',4,6)]):filters.append(text(s,'step'+str(i),930,38,a,b))
 run(['ffmpeg','-hide_banner','-loglevel','warning','-y','-filter_threads','1','-framerate','6','-i',str(seq/'%04d.png'),'-vf',','.join(filters),'-t','6','-c:v','libx264','-threads','2','-preset','medium','-crf','18','-pix_fmt','yuv420p','-movflags','+faststart',str(P/('SlimeSweep_'+kind+'_1080p.mp4'))])
 print('ENCODED',kind,flush=True)
f=P/'concat.txt';f.write_text(''.join("file 'SlimeSweep_"+k+"_1080p.mp4'\n" for k in ['keyboard','crevice','seat']))
run(['ffmpeg','-hide_banner','-loglevel','warning','-y','-f','concat','-safe','0','-i',str(f),'-c','copy','-movflags','+faststart',str(P/'SlimeSweep_V2_full_1080p.mp4')])
with zipfile.ZipFile(P/'SlimeSweep_V2_sources.zip','w',zipfile.ZIP_DEFLATED) as z:
 for k in ['keyboard','crevice','seat']:z.write(P/('SlimeSweep_'+k+'_v2.blend'),'SlimeSweep_'+k+'_v2.blend')
 for f in ['build.py','render_guided.py','denoise_guided.py','encode_v2.py','validate.py','animation_validation.json','README.md']:z.write(P/f,f)
for k in ['keyboard','crevice','seat']:
 run(['ffprobe','-v','error','-show_entries','stream=width,height,nb_frames,avg_frame_rate:format=duration','-of','json',str(P/('SlimeSweep_'+k+'_1080p.mp4'))])
