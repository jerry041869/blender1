import bpy,pathlib,sys
P=pathlib.Path('/workspace/output/slimesweep_v2')
kinds=['keyboard'] if '--preview' in sys.argv else ['keyboard','crevice','seat']
for kind in kinds:
 bpy.ops.wm.open_mainfile(filepath=str(P/('SlimeSweep_'+kind+'_v2.blend')))
 s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.samples=4;s.cycles.use_adaptive_sampling=False;s.cycles.use_denoising=False;s.cycles.max_bounces=3;s.cycles.diffuse_bounces=1;s.cycles.glossy_bounces=2;s.cycles.transmission_bounces=2;s.render.use_persistent_data=True
 p=bpy.data.materials['Translucent chartreuse slime'].node_tree.nodes.get('Principled BSDF');p.inputs['Subsurface Weight'].default_value=0;p.inputs['Transmission Weight'].default_value=.12
 s.view_layers[0].cycles.denoising_store_passes=True;s.render.image_settings.file_format='OPEN_EXR_MULTILAYER';s.render.image_settings.color_depth='16';s.render.image_settings.exr_codec='ZIP'
 s.frame_start=1;s.frame_end=72;s.frame_step=2;s.render.filepath=str(P/kind/'guided'/'frame_');s.frame_set(1)
 folder=P/kind/'guided';folder.mkdir(parents=True,exist_ok=True)
 bpy.ops.wm.save_as_mainfile(filepath=bpy.data.filepath)
 for f in ([45] if '--preview' in sys.argv else range(1,73,2)):
  p=folder/('frame_%04d.exr'%f)
  if p.exists():continue
  s.frame_set(f);s.render.filepath=str(p);bpy.ops.render.render(write_still=True)
