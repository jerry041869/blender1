import bpy,json,pathlib
from mathutils import Vector
P=pathlib.Path('/workspace/output/slimesweep_v2');report={}
for kind in ['keyboard','crevice','seat']:
 bpy.ops.wm.open_mainfile(filepath=str(P/('SlimeSweep_'+kind+'_v2.blend')));s=bpy.context.scene;root=bpy.data.objects['Animated SlimeSweep assembly'];gel=bpy.data.objects['Living branching gel | animated implicit surface'];slider=bpy.data.objects['15 | Sage push slider']
 poses={}
 for f in [1,45,54,62,68,71]:
  s.frame_set(f);ev=gel.evaluated_get(bpy.context.evaluated_depsgraph_get());me=ev.to_mesh();xs=[(ev.matrix_world@v.co).x-root.location.x for v in me.vertices];ev.to_mesh_clear();poses[f]={'root':list(root.location),'slider_x':slider.location.x,'gel_min_x':min(xs) if xs else None}
 assert (Vector(poses[45]['root'])-Vector(poses[62]['root'])).length<1e-5
 assert poses[68]['slider_x']>poses[45]['slider_x']+1
 assert poses[71]['gel_min_x'] is None or poses[71]['gel_min_x']>poses[45]['gel_min_x']+3
 assert sum(o.name.startswith('Surface bonded dust') for o in s.objects)>=100
 report[kind]=poses
(P/'animation_validation.json').write_text(json.dumps(report,indent=2));print('VALIDATED_PUSH_SPREAD_SURFACE_DUST_PULL_RECOVERY',list(report))
