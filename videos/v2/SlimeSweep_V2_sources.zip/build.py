import bpy, os, math, random, pathlib, sys
from mathutils import Vector
from mathutils.bvhtree import BVHTree
P=pathlib.Path('/workspace/output/slimesweep_v2');kind=os.environ.get('SWEEP_SCENE','keyboard');requested_kind=kind
os.environ['SWEEP_SCENE']='keyboard' if kind=='keyboard' else 'crevice'
src=pathlib.Path('/workspace/output/slimesweep_video/animate.py').read_text()
exec(src.split('# Approach, compress')[0])
kind=requested_kind
random.seed(81)
if kind=='seat':
 for o in list(sc.objects):
  if o.name.startswith(('Cabinet','Recessed')):bpy.data.objects.remove(o,do_unlink=True)
 leather=mat('Charcoal leather',(.065,.08,.085),.42)
 p=leather.node_tree.nodes.get('Principled BSDF');noise=leather.node_tree.nodes.new('ShaderNodeTexNoise');noise.inputs['Scale'].default_value=150
 bump=leather.node_tree.nodes.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.16;bump.inputs['Distance'].default_value=.035;leather.node_tree.links.new(noise.outputs['Fac'],bump.inputs['Height']);leather.node_tree.links.new(bump.outputs[0],p.inputs['Normal'])
 for y in [-2.65,2.65]:
  box('Car seat cushion',(-11.5,y,.76),(10,4.55,1.7),leather,.65)
  box('Car seat backrest',(-16,y,3.9),(1.8,4.55,5.8),leather,.65)
  box('Car seat headrest',(-16,y,7.5),(1.4,2.9,1.7),leather,.45)
  for j in range(4):box('Leather stitched panel',(-12+j*1.15,y,1.63),(.025,3.5,.018),label,.005)
oldgel=bpy.data.objects.get('20 | Irregular extruded cleaning gel');oldgel.hide_render=True;oldgel.hide_viewport=True
for o in root.children:
 if o.name.startswith('22 |'):o.hide_render=True
gelmat=mat('Translucent chartreuse slime',(.48,.67,.08),.16)
p=gelmat.node_tree.nodes.get('Principled BSDF');p.inputs['Transmission Weight'].default_value=.22;p.inputs['IOR'].default_value=1.36;p.inputs['Subsurface Weight'].default_value=.08;p.inputs['Coat Weight'].default_value=.35;p.inputs['Coat Roughness'].default_value=.13
mb=bpy.data.metaballs.new('Continuous spreading viscoelastic field');mb.resolution=.09;mb.render_resolution=.075;mb.threshold=.65
gel=bpy.data.objects.new('Living branching gel | animated implicit surface',mb);sc.collection.objects.link(gel);gel.parent=root;gel.scale.z=.50;mb.materials.append(gelmat)
if kind=='seat':gel.location.z=-.10
# Every element grows and changes position independently; the connected surface
# extends branches, merges and contracts instead of scaling a fixed mesh.
def element(co,r,delay=0):
 e=mb.elements.new();e.co=co
 states=[(1,.018,0,0,.68),(16,.55,.15,.10,.60),(25,.85,.65,.35,.35),(38+delay,1,1,1,co[2]),(48,1.05,1,1,co[2]),(54,.80,1.12,.65,.45),(62,.58,.38,.16,.60),(68,.25,.09,.03,.68),(72,.018,0,0,.68)]
 for f,amount,length,width,z in states:
  e.radius=max(.008,r*amount);e.co=(-6.35+(co[0]+6.35)*length,co[1]*width,z)
  e.keyframe_insert(data_path='radius',frame=f);e.keyframe_insert(data_path='co',frame=f)
 return e
element((-6.48,0,.68),.57)
for j in range(18):element((-6.55-j*.255,0,.24),.36 if kind!='seat' else .30,j//5)
for x in [-8.42,-10.28]:
 for side in [-1,1]:
  length=1.85 if kind=='keyboard' else (2.3 if kind=='crevice' else .29)
  for j in range(1,10):
   y=side*length*j/9
   element((x+.04*math.sin(j),y,.22),(.28 if kind=='keyboard' else .36)*(1-.28*j/10),j//2)
   if kind=='crevice' and j>5:element((x-.16*(j-5),y+.10,.24),.28,j//2)
contactz=.40 if kind=='keyboard' else .02
motion=[(1,(3.8,0,contactz+1.1)),(18,(1.1,0,contactz+.25)),(30,(0,0,contactz)),(48,(0,0,contactz)),(60,(0,0,contactz)),(68,(0,0,contactz)),(72,(1.3,0,contactz+.3))]
for f,co in motion:root.location=co;root.keyframe_insert(data_path='location',frame=f)
for o in root.children:
 if o.name.startswith(('15 |','16 |')):
  x=o.location.x
  for f,dx in [(1,1.4),(18,1.0),(36,0),(48,0),(60,.9),(68,1.4),(72,1.4)]:o.location.x=x+dx;o.keyframe_insert(data_path='location',frame=f)
def surface():
 deps=bpy.context.evaluated_depsgraph_get();ev=gel.evaluated_get(deps);me=ev.to_mesh();verts=[ev.matrix_world@v.co for v in me.vertices];faces=[list(p.vertices) for p in me.polygons];tree=BVHTree.FromPolygons(verts,faces);ev.to_mesh_clear();return tree
sc.frame_set(45);tree=surface();rootat=root.location.copy();anchors=[]
for attempt in range(5000):
 x=random.uniform(-10.9,-6.9);y=random.uniform(-2.2,2.2) if kind!='seat' else random.uniform(-.17,.17)
 hit,n,_,_=tree.ray_cast(Vector((x,y,4)),Vector((0,0,-1)))
 if hit is not None:
  anchors.append((Vector((x,y,0)),random.uniform(.025,.06)))
 if len(anchors)>=130:break
particles=[];floor=.36 if kind=='keyboard' else -.08
for i,(anchor,r) in enumerate(anchors):
 o=uv('Surface bonded dust %03d'%i,(anchor.x,anchor.y,floor),(r,r*.75,r*.4),dustmat);particles.append((o,anchor,r))
# Bake per-frame nearest-surface constraints. All dust follows the evaluated
# deformed surface with a small embedded offset, including after retraction.
attached={};previous={}
for f in range(1,73):
 sc.frame_set(f);tree=surface();delta=root.location-Vector((0,0,contactz))
 for i,(o,a,r) in enumerate(particles):
  target=Vector((a.x+delta.x,a.y+delta.y,4+delta.z));hit,n,_,_=tree.ray_cast(target,Vector((0,0,-1)))
  if i not in attached and 24<=f<=48 and hit is not None and abs(delta.x)<.7:attached[i]=f
  if i in attached:
   if hit is None:
    hit,n,_,_=tree.find_nearest(previous.get(i,Vector((a.x+delta.x,a.y,contactz+.2+delta.z))))
   if hit is None:hit=Vector((-6.2+delta.x,delta.y,contactz+.34+delta.z));n=Vector((0,0,1))
   pos=hit+n*r*.15;previous[i]=pos.copy();blend=min(1,(f-attached[i]+1)/3)
   o.location=Vector((a.x,a.y,floor)).lerp(pos,blend);o.rotation_euler=n.to_track_quat('Z','Y').to_euler()
  else:o.location=(a.x,a.y,floor)
  o.keyframe_insert(data_path='location',frame=f);o.keyframe_insert(data_path='rotation_euler',frame=f)
  if f>=64:
   factor=max(.01,(72-f)/8);o.scale=(r*factor,r*.75*factor,r*.4*factor);o.keyframe_insert(data_path='scale',frame=f)
print('SURFACE_BINDING',kind,len(particles),len(attached),flush=True)
def area(loc,target,power,size,col):
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.data.energy=power;o.data.size=size;o.data.color=col;o.visible_camera=False;o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler()
area((-7,-7,12),(-8,0,.5),2400,10,(1,.94,.85));area((-4,6,10),(-8,0,.5),2400,8,(.80,.91,1));area((-12,-4,2),(-9,0,.4),350,5,(1,.96,.86))
bpy.ops.object.camera_add();cam=bpy.context.object;sc.camera=cam;cam.data.type='ORTHO'
for f,size,target in [(1,29,(-5,0,.6)),(26,17,(-8,0,.5)),(48,17,(-8,0,.5)),(60,21,(-6,0,1)),(72,29,(-4,0,1))]:
 t=Vector(target);loc=t+Vector((-1,-9,28) if kind=='keyboard' else ((5,-5,30) if kind=='seat' else (0,-25,8)))
 cam.location=loc;cam.rotation_euler=(t-loc).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=size;cam.keyframe_insert(data_path='location',frame=f);cam.keyframe_insert(data_path='rotation_euler',frame=f);cam.data.keyframe_insert(data_path='ortho_scale',frame=f)
sc.render.engine='CYCLES';sc.cycles.samples=8;sc.cycles.use_denoising=False;sc.cycles.max_bounces=4;sc.cycles.use_adaptive_sampling=True;sc.cycles.adaptive_threshold=.12;sc.cycles.adaptive_min_samples=4
sc.render.resolution_x=1920;sc.render.resolution_y=1080;sc.render.resolution_percentage=100;sc.render.fps=12;sc.frame_start=1;sc.frame_end=72;sc.frame_step=2;sc.world.color=(.25,.25,.25)
sc.render.image_settings.file_format='PNG';sc.render.image_settings.color_mode='RGB';folder=P/kind/'raw';folder.mkdir(parents=True,exist_ok=True);sc.render.filepath=str(folder/'frame_')
sc['Scope']='Art-directed viscoelastic implicit-surface animation. Surface-constrained dust adhesion; not a biological simulation.'
sc.frame_set(1);bpy.ops.wm.save_as_mainfile(filepath=str(P/('SlimeSweep_'+kind+'_v2.blend')))
if '--build-only' in sys.argv:pass
elif '--preview' in sys.argv:
 sc.frame_set(45);sc.render.filepath=str(P/(kind+'_contact.png'));bpy.ops.render.render(write_still=True)
else:bpy.ops.render.render(animation=True)
