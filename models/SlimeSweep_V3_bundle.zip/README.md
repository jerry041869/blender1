# SlimeSweep V3 — concept model

Created in Blender 4.3.2 from the supplied design board. This is a visual interpretation, not manufacturing CAD or a validated mechanical assembly.

- `SlimeSweep_V3.blend`: editable product parts, studio lights and camera.
- `SlimeSweep_V3.glb`: portable product model with materials; excludes the studio.
- `SlimeSweep_V3_preview.png`: rendered product view.
- `create_model.py`: reproducible Blender Python generator.

Parts include the ivory body frame and nozzle, transparent reservoir, gel charge, piston, seal, return spring, inclined drive ramp, ribbed sage slider, flexible hanging loop and irregular extruded gel. Dimensions and hidden mechanisms are approximate because the reference is a perspective concept sheet. No engineering tolerances, movement simulation or watertight print preparation is implied.

Regenerate with `blender -b --factory-startup -t 6 --python /workspace/output/slimesweep/create_model.py`. Denoising is disabled because the installed Blender build lacks OpenImageDenoise.

Blender MCP 2.2.6 is installed separately under `/workspace/tools/blender-mcp-venv`; its startup and protocol check scripts are `/workspace/tools/start_blender_mcp.py` and `/workspace/tools/check_blender_mcp.py`. The current Codex session may need a restart before newly registered MCP tools appear.
