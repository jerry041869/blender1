import bpy, math, random, os
from mathutils import Vector
from math import sin, cos, pi
OUT='/workspace/output/slimesweep'
random.seed(17)
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
for d in bpy.data.materials: bpy.data.materials.remove(d)
def mat(name,color,metal=0,rough=.3,trans=0):
 m=bpy.data.materials.new(name); m.diffuse_color=(*color,1); m.use_nodes=True
 p=m.node_tree.nodes.get('Principled BSDF'); p.inputs['Base Color'].default_value=(*color,1); p.inputs['Metallic'].default_value=metal; p.inputs['Roughness'].default_value=rough; p.inputs['Transmission Weight'].default_value=trans; p.inputs['IOR'].default_value=1.43
 return m
ivory=mat('Warm ivory | ABS shell',(.78,.72,.63),.12,.23)
green=mat('Sage | TPE grip',(.18,.32,.25),0,.38)
glass=mat('Clear pale sage | PC reservoir',(.65,.82,.69),0,.12,.92)
gel=mat('Yellow green | viscoelastic cleaning gel',(.58,.69,.08),0,.17,.65)
steel=mat('Brushed stainless steel',(.42,.46,.43),.85,.25)
dark=mat('Piston seals',(.085,.11,.095),0,.35)
gold=mat('Suspended golden particles',(.87,.64,.11),.4,.27)
def finish(o,name,material):
 o.name=name; o.data.materials.append(material)
 if o.type=='MESH':
  for p in o.data.polygons:p.use_smooth=True
 return o
def uv(name,loc,scale,material):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=48,ring_count=24,location=loc); o=bpy.context.object; o.scale=scale; bpy.ops.object.transform_apply(location=False,rotation=False,scale=True); return finish(o,name,material)
def box(name,loc,scale,material,bevel=.06):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.dimensions=scale;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);finish(o,name,material)
 if bevel: mod=o.modifiers.new('Soft moulded edges','BEVEL');mod.width=bevel;mod.segments=5;o.modifiers.new('Weighted normals','WEIGHTED_NORMAL')
 return o
def cylinder(name,x,r,depth,material,z=.42):
 bpy.ops.mesh.primitive_cylinder_add(vertices=72,radius=r,depth=depth,location=(x,0,z),rotation=(0,pi/2,0));o=bpy.context.object;finish(o,name,material);b=o.modifiers.new('Machined edges','BEVEL');b.width=.015;b.segments=3;return o
def tube(name,pts,r,material,cyclic=False):
 cu=bpy.data.curves.new(name,'CURVE');cu.dimensions='3D';cu.resolution_u=24;cu.bevel_depth=r;cu.bevel_resolution=5
 s=cu.splines.new('BEZIER');s.bezier_points.add(len(pts)-1)
 for b,p in zip(s.bezier_points,pts):b.co=p;b.handle_left_type='AUTO';b.handle_right_type='AUTO'
 s.use_cyclic_u=cyclic;o=bpy.data.objects.new(name,cu);bpy.context.collection.objects.link(o);o.data.materials.append(material);return o
# Long axis X. Model units are centimetres; overall length approximately 28 cm.
def lathe(name,profile,material):
 verts=[];faces=[];N=96
 for x,ry,rz in profile:
  for i in range(N):
   a=2*pi*i/N;verts.append((x,ry*cos(a),.42+rz*sin(a)))
 for j in range(len(profile)-1):
  for i in range(N): a=j*N+i;b=j*N+(i+1)%N;faces.append((a,b,b+N,a+N))
 faces.append(tuple(range(N-1,-1,-1)));faces.append(tuple((len(profile)-1)*N+i for i in range(N)))
 me=bpy.data.meshes.new(name);me.from_pydata(verts,[],faces);me.update();o=bpy.data.objects.new(name,me);bpy.context.collection.objects.link(o);return finish(o,name,material)
lathe('01 | Sculpted tapered nozzle', [(-6.5,.40,.38),(-6.35,.44,.40),(-5.95,.48,.44),(-5.45,.68,.58),(-4.7,1.03,.83),(-3.95,1.23,.94),(-3.35,1.25,.96)],ivory)
cylinder('02 | Flexible outlet rim',-6.48,.41,.15,green)
cylinder('03 | Nozzle seal',-6.57,.36,.08,steel)
# Open structural frame leaves the transparent storage capsule visible.
box('04 | Lower structural rail',(.45,0,-.51),(8.3,1.55,.30),ivory,.14)
box('05 | Upper structural rail',(.50,0,1.37),(8.45,1.2,.26),ivory,.12)
lathe('06 | Rear rounded cap',[(4.05,1.04,.95),(4.35,1.12,1.01),(4.75,1.10,.97),(5.05,.92,.82),(5.13,.70,.66)],ivory)
lathe('07 | Transparent reservoir', [(-3.65,.96,.79),(-3.40,1.02,.83),(3.95,1.02,.83),(4.15,.95,.78)],glass)
lathe('08 | Gel charge in chamber',[(-3.45,.77,.58),(-3.25,.88,.67),(2.65,.88,.67),(2.75,.81,.61)],gel)
for x in [-3.5,3.96]:
 cylinder('09 | Reservoir perimeter gasket',x,1.025,.075,dark)
cylinder('10 | Piston disc',2.91,.88,.22,ivory)
cylinder('11 | Piston seal',2.77,.90,.10,dark)
cylinder('12 | Central piston rod',3.77,.12,1.65,steel)
pts=[]
for i in range(361):
 t=i/360; a=t*2*pi*12;pts.append((3.12+1.55*t,.33*cos(a),.42+.33*sin(a)))
tube('13 | Return spring',pts,.035,steel)
box('14 | Slider channel',(.0,0,1.53),(5.45,.47,.06),dark,.025)
box('15 | Sage push slider',(-1.15,0,1.72),(1.65,1.10,.36),green,.12)
for i in range(13):box('16 | Slider tactile rib %02d'%i,(-1.83+i*.112,0,1.915),(.035,.83,.025),green,.01)
o=box('17 | Inclined drive ramp',(3.45,0,.48),(1.50,.28,.15),gold,.03);o.rotation_euler[1]=-.43
for y in [-1,1]:tube('18 | Shell seam', [(-6.15,y*.43,.38),(-4.5,y*1.1,.31),(-3.4,y*1.24,.28),(3.8,y*1.02,.27),(4.85,y*.89,.30)],.012,dark)
tube('19 | Flexible hanging loop',[(4.78,0,.65),(5.6,0,1.1),(6.60,0,1.00),(6.95,0,.45),(6.65,0,-.06),(5.6,0,-.12),(4.85,0,.20)],.19,green,True)
# Smooth connected, irregular extruded cleaning gel using metaballs.
mb=bpy.data.metaballs.new('Organic gel surface');mb.resolution=.095;mb.render_resolution=.065;mb.threshold=.65
o=bpy.data.objects.new('20 | Irregular extruded cleaning gel',mb);bpy.context.collection.objects.link(o)
for loc,r in [((-6.65,0,.42),.63),((-7.25,0,.32),.93),((-8.1,.10,.21),1.05),((-9,.05,.05),1.00),((-9.8,.0,-.10),.72),((-8.8,-.65,-.12),.68),((-7.8,.60,-.08),.67),((-9.5,.5,-.18),.52)]:
 e=mb.elements.new();e.co=loc;e.radius=r
bpy.context.view_layer.objects.active=o;o.select_set(True);bpy.ops.object.convert(target='MESH');finish(bpy.context.object,'20 | Irregular extruded cleaning gel',gel);bpy.context.object.select_set(False)
for i in range(110):
 x=random.uniform(-3.2,2.55);a=random.uniform(0,2*pi);r=random.uniform(.15,.69)
 uv('21 | Gel microbubble %03d'%i,(x,r*cos(a),.42+r*.72*sin(a)),(.018,)*3,gold)
for i in range(50):
 x=random.uniform(-9.65,-7.10);y=random.uniform(-.44,.44);z=random.uniform(-.14,.48)
 uv('22 | Gel speckle %03d'%i,(x,y,z),(.022,)*3,gold)
# Raised identity printed on the upper rail.
cu=bpy.data.curves.new('Product mark','FONT');cu.body='SlimeSweep  /  V3';cu.size=.27;cu.extrude=.001
o=bpy.data.objects.new('23 | Product wordmark',cu);bpy.context.collection.objects.link(o);o.location=(-2.7,-.36,1.515);cu.materials.append(green)
product=list(bpy.context.scene.objects)
for o in product:o.select_set(True)
bpy.context.scene.unit_settings.system='METRIC';bpy.context.scene.unit_settings.scale_length=.01
bpy.ops.export_scene.gltf(filepath=OUT+'/SlimeSweep_V3.glb',export_format='GLB',use_selection=True)
bpy.ops.object.select_all(action='DESELECT')
floor=mat('Studio warm charcoal',(.065,.074,.07),0,.5)
box('Studio floor',(-1,0,-.92),(200,200,.15),floor,.02)
def area(name,loc,power,size,color):
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.name=name;o.data.energy=power;o.data.shape='DISK';o.data.size=size;o.data.color=color;o.rotation_euler=(Vector((-2,0,.2))-o.location).to_track_quat('-Z','Y').to_euler()
area('Large softbox',(-4,-6,11),1800,9,(1,.90,.77));area('Edge strip',(2,6,8),2300,7,(.78,.88,1));area('Nozzle fill',(-11,-1,5),700,5,(1,.94,.70))
bpy.ops.object.camera_add(location=(-14,-23,16));cam=bpy.context.object;cam.rotation_euler=(Vector((-1.7,0,.4))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=21.0;bpy.context.scene.camera=cam
sc=bpy.context.scene;sc.render.engine='CYCLES';sc.cycles.samples=32;sc.cycles.use_denoising=False;sc.render.resolution_x=1500;sc.render.resolution_y=900;sc.render.resolution_percentage=100;sc.world.color=(.24,.24,.24);sc.view_settings.view_transform='AgX'
sc['Design reference']='SlimeSweep V3 user supplied concept board';sc['Model scope']='Visual concept approximation; not fabrication CAD. Approx. 280mm overall.'
bpy.ops.wm.save_as_mainfile(filepath=OUT+'/SlimeSweep_V3.blend');sc.render.filepath=OUT+'/SlimeSweep_V3_preview.png';bpy.ops.render.render(write_still=True)
print('MODEL_COMPLETE',OUT)
